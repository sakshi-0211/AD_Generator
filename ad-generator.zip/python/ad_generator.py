#!/usr/bin/env python3
"""
Ad Generator Python Script - Bridge between Next.js and the original Streamlit app
"""

import sys
import json
import base64
import io
from PIL import Image, ImageDraw, ImageFont
import os

# Import the original classes from your Streamlit app
# Note: This is a simplified version for demonstration
class AdCopyGenerator:
    def __init__(self, api_key=None):
        self.api_key = api_key
        
    def generate_ad_copy(self, product_name, product_description, audience, tone, dimensions, examples=None):
        """Generate ad copy based on product info and tone"""
        # This is a simplified mock implementation
        # In production, you would use the actual Gemini API integration
        return {
            "headline": f"Introducing {product_name}",
            "main_copy": f"Perfect for {audience}. {product_description[:100]}...",
            "cta": "Get Yours Today"
        }

class AdImageGenerator:
    def __init__(self, api_key=None):
        self.api_key = api_key
        
        # Define tone-specific color schemes (simplified from original)
        self.color_schemes = {
            "Professional": {
                "background": (240, 248, 255),  # AliceBlue
                "header": (41, 128, 185),       # Blue
                "text": (44, 62, 80),           # Dark blue/grey
                "button": (52, 152, 219),       # Light blue
                "button_text": (255, 255, 255)  # White
            },
            "Friendly": {
                "background": (255, 250, 205),  # LemonChiffon
                "header": (46, 204, 113),       # Green
                "text": (44, 62, 80),           # Dark blue/grey
                "button": (39, 174, 96),        # Darker green
                "button_text": (255, 255, 255)  # White
            },
            # Add other tones as needed
        }
    
    def create_ad_image(self, ad_content, dimensions, product_name, product_description, tone):
        """Create a simple ad image (simplified from original)"""
        try:
            # Parse dimensions
            width, height = map(int, dimensions.split('x'))
            
            # Get tone-specific color scheme
            colors = self.color_schemes.get(tone, self.color_schemes["Professional"])
            
            # Create a background with tone-specific color
            img = Image.new('RGB', (width, height), color=colors["background"])
            draw = ImageDraw.Draw(img)
            
            # Header and footer with tone-specific colors
            draw.rectangle([(0, 0), (width, int(height/10))], fill=colors["header"])
            draw.rectangle([(0, height-int(height/10)), (width, height)], fill=colors["header"])
            
            # Add brand/product name
            draw.text((20, int(height/30)), product_name.upper(), fill=(255, 255, 255))
            
            # Draw headline
            draw.text((20, int(height/6)), ad_content["headline"], fill=colors["text"])
            
            # Draw main copy
            draw.text((20, int(height/3)), ad_content["main_copy"], fill=colors["text"])
            
            # Draw CTA in a button-like shape
            cta_y = height - int(height/4)
            draw.rectangle(
                [(width/2 - 100, cta_y - 20),
                 (width/2 + 100, cta_y + 20)],
                fill=colors["button"]
            )
            draw.text((width/2 - 80, cta_y - 10), ad_content["cta"], fill=colors["button_text"])
            
            # Convert image for web display
            buf = io.BytesIO()
            img.save(buf, format='PNG')
            return base64.b64encode(buf.getvalue()).decode('utf-8')
            
        except Exception as e:
            print(f"Error creating ad image: {str(e)}")
            return None

def main():
    """Main function to process input and generate ad"""
    if len(sys.argv) != 3:
        print("Usage: python ad_generator.py <input_json_path> <output_json_path>")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    try:
        # Read input data
        with open(input_path, 'r') as f:
            data = json.load(f)
        
        # Extract parameters
        product_name = data.get('productName', '')
        product_description = data.get('productDescription', '')
        dimensions = data.get('dimensions', '1200x628')
        audience = data.get('audience', '')
        tone = data.get('tone', 'Professional')
        num_examples = data.get('numExamples', 0)
        
        # Initialize generators
        copy_generator = AdCopyGenerator()
        image_generator = AdImageGenerator()
        
        # Generate ad copy
        ad_content = copy_generator.generate_ad_copy(
            product_name, 
            product_description, 
            audience, 
            tone, 
            dimensions
        )
        
        # Generate ad image
        image_base64 = image_generator.create_ad_image(
            ad_content, 
            dimensions, 
            product_name, 
            product_description, 
            tone
        )
        
        # Prepare output
        output = {
            'adContent': ad_content,
            'imageUrl': f"data:image/png;base64,{image_base64}" if image_base64 else "/placeholder.svg?height=600&width=800"
        }
        
        # Write output
        with open(output_path, 'w') as f:
            json.dump(output, f)
        
    except Exception as e:
        print(f"Error: {str(e)}")
        # Write error output
        with open(output_path, 'w') as f:
            json.dump({
                'error': str(e),
                'adContent': {
                    'headline': f"Error: {str(e)}",
                    'main_copy': "There was an error generating your ad.",
                    'cta': "Try Again"
                },
                'imageUrl': "/placeholder.svg?height=600&width=800"
            }, f)
        sys.exit(1)

if __name__ == "__main__":
    main()

