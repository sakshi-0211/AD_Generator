import { type NextRequest, NextResponse } from "next/server"
import { spawn } from "child_process"
import path from "path"
import fs from "fs"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Create a temporary JSON file to pass data to the Python script
    const tempInputPath = path.join(process.cwd(), "temp-input.json")
    const tempOutputPath = path.join(process.cwd(), "temp-output.json")

    fs.writeFileSync(tempInputPath, JSON.stringify(data))

    // Execute the Python script
    const result = await new Promise((resolve, reject) => {
      const pythonProcess = spawn("python", [
        path.join(process.cwd(), "python", "ad_generator.py"),
        tempInputPath,
        tempOutputPath,
      ])

      let errorData = ""

      pythonProcess.stderr.on("data", (data) => {
        errorData += data.toString()
      })

      pythonProcess.on("close", (code) => {
        if (code !== 0) {
          reject(new Error(`Python process exited with code ${code}: ${errorData}`))
          return
        }

        try {
          // Read the output file
          const outputData = JSON.parse(fs.readFileSync(tempOutputPath, "utf8"))
          resolve(outputData)
        } catch (err) {
          reject(err)
        } finally {
          // Clean up temp files
          if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath)
          if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath)
        }
      })
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json(
      {
        error: "Failed to generate ad",
        adContent: {
          headline: "Sample Headline",
          main_copy: "This is a fallback ad copy when the Python script fails.",
          cta: "Click Here",
        },
        imageUrl: "/placeholder.svg?height=600&width=800",
      },
      { status: 500 },
    )
  }
}

