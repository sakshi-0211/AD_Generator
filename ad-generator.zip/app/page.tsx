"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { ImageIcon, FileJson, Sparkles } from "lucide-react"

// Form schema
const formSchema = z.object({
  productName: z.string().min(2, { message: "Product name must be at least 2 characters." }),
  productDescription: z.string().min(10, { message: "Description must be at least 10 characters." }),
  dimensions: z.string(),
  audience: z.string().min(5, { message: "Target audience must be at least 5 characters." }),
  tone: z.string(),
  numExamples: z.number().min(0).max(5),
})

type AdContent = {
  headline: string
  main_copy: string
  cta: string
}

export default function AdGenerator() {
  const [adContent, setAdContent] = useState<AdContent | null>(null)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      productName: "Smart Watch",
      productDescription: "A smartwatch with advanced health tracking, GPS, and 7-day battery life.",
      dimensions: "1200x628",
      audience: "Health-conscious professionals aged 25-45",
      tone: "Professional",
      numExamples: 2,
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsGenerating(true)

    try {
      // In a real implementation, this would call your Python API
      const response = await fetch("/api/generate-ad", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      })

      if (!response.ok) {
        throw new Error("Failed to generate ad")
      }

      const data = await response.json()
      setAdContent(data.adContent)
      setGeneratedImage(data.imageUrl)
    } catch (error) {
      console.error("Error generating ad:", error)
      // Fallback to mock data for demo purposes
      setAdContent({
        headline: `Introducing ${values.productName}: Elevate Your Experience`,
        main_copy: `Designed specifically for ${values.audience}. ${values.productDescription.substring(0, 100)}...`,
        cta: "Get Yours Today",
      })
      setGeneratedImage(`/placeholder.svg?height=600&width=800`)
    } finally {
      setIsGenerating(false)
    }
  }

  // Helper function to get tone-specific colors
  const getToneColors = (tone: string) => {
    const colorSchemes: Record<
      string,
      { bg: string; header: string; text: string; button: string; buttonText: string }
    > = {
      Professional: {
        bg: "bg-blue-50",
        header: "bg-blue-600 text-white",
        text: "text-slate-800",
        button: "bg-blue-500 hover:bg-blue-600",
        buttonText: "text-white",
      },
      Friendly: {
        bg: "bg-green-50",
        header: "bg-green-600 text-white",
        text: "text-slate-800",
        button: "bg-green-500 hover:bg-green-600",
        buttonText: "text-white",
      },
      Humorous: {
        bg: "bg-orange-50",
        header: "bg-orange-500 text-white",
        text: "text-slate-800",
        button: "bg-orange-500 hover:bg-orange-600",
        buttonText: "text-white",
      },
      Urgent: {
        bg: "bg-red-50",
        header: "bg-red-600 text-white",
        text: "text-slate-800",
        button: "bg-red-600 hover:bg-red-700",
        buttonText: "text-white",
      },
      Inspirational: {
        bg: "bg-purple-50",
        header: "bg-purple-600 text-white",
        text: "text-slate-800",
        button: "bg-purple-500 hover:bg-purple-600",
        buttonText: "text-white",
      },
      Luxurious: {
        bg: "bg-slate-50",
        header: "bg-slate-800 text-white",
        text: "text-slate-800",
        button: "bg-slate-800 hover:bg-slate-900",
        buttonText: "text-amber-400",
      },
    }

    return colorSchemes[tone] || colorSchemes["Professional"]
  }

  const toneColors = getToneColors(form.watch("tone"))

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Creative Ad Copy Generator</h1>
        <p className="text-muted-foreground mt-2">
          Generate professional ad copy and visuals for your marketing campaigns
        </p>
      </div>

      <div className="grid md:grid-cols-[1fr_1.2fr] gap-8">
        <div>
          <div className="bg-white rounded-lg border shadow-sm">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold">Ad Configuration</h2>
              <p className="text-sm text-gray-500">Enter your product details and preferences</p>
            </div>
            <div className="p-6">
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Product Name</label>
                    <input
                      {...form.register("productName")}
                      className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Smart Watch"
                    />
                    {form.formState.errors.productName && (
                      <p className="text-red-500 text-xs mt-1">{form.formState.errors.productName.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Ad Dimensions</label>
                    <select
                      {...form.register("dimensions")}
                      className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="1200x628">1200x628 - Facebook/Twitter</option>
                      <option value="1080x1080">1080x1080 - Instagram</option>
                      <option value="800x600">800x600 - Display Ad</option>
                      <option value="320x480">320x480 - Mobile Ad</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Product Description</label>
                  <textarea
                    {...form.register("productDescription")}
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px]"
                    placeholder="Describe your product in detail"
                  />
                  {form.formState.errors.productDescription && (
                    <p className="text-red-500 text-xs mt-1">{form.formState.errors.productDescription.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Target Audience</label>
                  <input
                    {...form.register("audience")}
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Health-conscious professionals aged 25-45"
                  />
                  {form.formState.errors.audience && (
                    <p className="text-red-500 text-xs mt-1">{form.formState.errors.audience.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Ad Tone</label>
                  <select
                    {...form.register("tone")}
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Professional">Professional</option>
                    <option value="Friendly">Friendly</option>
                    <option value="Humorous">Humorous</option>
                    <option value="Urgent">Urgent</option>
                    <option value="Inspirational">Inspirational</option>
                    <option value="Luxurious">Luxurious</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">
                    Number of Examples to Use: {form.watch("numExamples")}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="5"
                    step="1"
                    {...form.register("numExamples", { valueAsNumber: true })}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <p className="text-xs text-gray-500 mt-1">How many similar examples to use for reference</p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
                  disabled={isGenerating}
                >
                  {isGenerating ? "Generating Ad..." : "Generate Ad"}
                </button>
              </form>
            </div>
          </div>

          <div className="mt-6 bg-white rounded-lg border shadow-sm">
            <details className="group">
              <summary className="flex justify-between items-center font-medium cursor-pointer p-4">
                <span>About Ad Tones</span>
                <span className="transition group-open:rotate-180">
                  <svg
                    fill="none"
                    height="24"
                    width="24"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </span>
              </summary>
              <div className="p-4 pt-0 border-t">
                <div className="grid gap-2 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="w-3 h-3 mt-1 rounded-full bg-blue-500"></div>
                    <div>
                      <span className="font-medium">Professional:</span> Clean, corporate style with minimalist approach
                      for business audiences
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-3 h-3 mt-1 rounded-full bg-green-500"></div>
                    <div>
                      <span className="font-medium">Friendly:</span> Warm, approachable style with conversational
                      language
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-3 h-3 mt-1 rounded-full bg-orange-500"></div>
                    <div>
                      <span className="font-medium">Humorous:</span> Playful and witty approach to capture attention
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-3 h-3 mt-1 rounded-full bg-red-500"></div>
                    <div>
                      <span className="font-medium">Urgent:</span> Creates a sense of time pressure or limited
                      availability
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-3 h-3 mt-1 rounded-full bg-purple-500"></div>
                    <div>
                      <span className="font-medium">Inspirational:</span> Emotionally uplifting content focused on
                      aspirations
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-3 h-3 mt-1 rounded-full bg-slate-800"></div>
                    <div>
                      <span className="font-medium">Luxurious:</span> Elegant, premium feel for high-end products
                    </div>
                  </div>
                </div>
              </div>
            </details>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-lg border shadow-sm h-full flex flex-col">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold">Generated Ad</h2>
              <p className="text-sm text-gray-500">Preview your ad content and visuals</p>
            </div>
            <div className="p-6 flex-1">
              {adContent ? (
                <div className={`rounded-lg overflow-hidden border ${toneColors.bg}`}>
                  <div className={`p-3 ${toneColors.header}`}>
                    <div className="text-sm font-medium">{form.watch("productName")}</div>
                  </div>

                  <div className="grid md:grid-cols-[1.5fr_1fr] gap-4 p-6">
                    <div className="space-y-4">
                      <h2 className={`text-2xl font-bold ${toneColors.text}`}>{adContent.headline}</h2>
                      <p className="text-slate-600">{adContent.main_copy}</p>

                      <div className="pt-4">
                        <button
                          className={`px-6 py-2 rounded-md font-medium ${toneColors.button} ${toneColors.buttonText}`}
                        >
                          {adContent.cta}
                        </button>
                      </div>
                    </div>

                    {generatedImage && (
                      <div className="flex items-center justify-center">
                        <div className="relative aspect-video w-full max-w-[300px] rounded-md overflow-hidden border">
                          <img
                            src={generatedImage || "/placeholder.svg"}
                            alt="Generated ad visual"
                            className="object-cover w-full h-full"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className={`p-3 ${toneColors.header}`}></div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full py-12 text-center text-gray-500">
                  <Sparkles className="w-12 h-12 mb-4 opacity-20" />
                  <h3 className="text-lg font-medium">Your ad will appear here</h3>
                  <p className="max-w-md">
                    Fill out the form and click "Generate Ad" to create your custom ad content and visuals
                  </p>
                </div>
              )}
            </div>
            <div className="p-6 flex flex-col sm:flex-row gap-3 border-t">
              <button
                className="w-full sm:w-auto flex gap-2 items-center justify-center px-4 py-2 border rounded-md text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!generatedImage}
              >
                <ImageIcon className="w-4 h-4" />
                <span>Download Image</span>
              </button>
              <button
                className="w-full sm:w-auto flex gap-2 items-center justify-center px-4 py-2 border rounded-md text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!adContent}
              >
                <FileJson className="w-4 h-4" />
                <span>Download JSON</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-xl font-semibold mb-4">How to Use</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg border shadow-sm">
            <div className="p-4 border-b">
              <h3 className="text-lg font-medium">1. Enter Details</h3>
            </div>
            <div className="p-4">
              <p className="text-sm text-gray-500">
                Enter your product details and select your preferred tone and dimensions
              </p>
            </div>
          </div>
          <div className="bg-white rounded-lg border shadow-sm">
            <div className="p-4 border-b">
              <h3 className="text-lg font-medium">2. Generate</h3>
            </div>
            <div className="p-4">
              <p className="text-sm text-gray-500">Click "Generate Ad" to create custom ad copy and visuals</p>
            </div>
          </div>
          <div className="bg-white rounded-lg border shadow-sm">
            <div className="p-4 border-b">
              <h3 className="text-lg font-medium">3. Download</h3>
            </div>
            <div className="p-4">
              <p className="text-sm text-gray-500">Download the generated assets for your marketing campaigns</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

